# DigiStayBook reviewer response

Reviewer and firm:
Review date:
Scope:
Decision: approve / conditional approval / further work required

## Document approval

| Document | Exact approved version | Amendments or conditions |
|---|---|---|
| Host Terms | | |
| Guest Terms | | |
| Privacy Policy | | |
| Consent | | |

## Decision register responses

### R01 Operator and jurisdiction
Confirm legal entity, ABN/ACN if applicable, business address and state; test the drafts' Victoria governing-law choice against the actual operator.
Response:
Evidence required:
Owner and due date:

### R02 Roles and obligations
Confirm roles by data class and which privacy, consumer and communications obligations apply to the actual business and markets.
Response:
Evidence required:
Owner and due date:

### R03 Overseas handling
Approve account agreements, provider disclosure, safeguards/countries and accurate endpoint language.
Response:
Evidence required:
Owner and due date:

### R04 Minors and third parties
Approve 16+ wording; address photos of minors/other people, uploader authority and response workflow.
Response:
Evidence required:
Owner and due date:

### R05 Publication rights
Approve licence/consent wording, host responsibilities, public visibility, takedown and external-copy limits.
Response:
Evidence required:
Owner and due date:

### R06 Retention and recovery
Set complete schedules and lawful safety holds; reconcile seven-day bucket recovery and backups with deletion statements.
Response:
Evidence required:
Owner and due date:

### R07 Feedback outage mismatch
Drafts describe checks before delivery. Code delivers ordinary feedback on provider failure. Choose policy and align wording/implementation.
Response:
Evidence required:
Owner and due date:

### R08 Screening accuracy and appeals
Approve calibrated thresholds, false-positive target, uncertainty/review wording and review/appeal route.
Response:
Evidence required:
Owner and due date:

### R09 Critical content handling
Draft Host Terms describe critical handling; current memory provider mapping is standard host review. Define severe-content routing and prove restricted access.
Response:
Evidence required:
Owner and due date:

### R10 Staffing and notification promises
Name reviewers, hours, urgent handling and incident contacts. Host held-memory/report email worker is not established by the operations-budget email setup.
Response:
Evidence required:
Owner and due date:

### R11 Billing and consumer wording
Review 28-day first-property trial, recurring pricing, cancellation, refunds, liability and launch-market consistency against actual checkout.
Response:
Evidence required:
Owner and due date:

### R12 Marketing and email claims
Verify consent/suppression implementation and provider before approving the Privacy Policy's communications claims.
Response:
Evidence required:
Owner and due date:

### R13 Upload and image limitations
Approve limits, transformed-image handling, HEIC outcome and image-contact detection gap; avoid claiming comprehensive safety coverage.
Response:
Evidence required:
Owner and due date:

### R14 Approval record
Approve final versions together; record exact texts, reviewer/date, outstanding conditions and scope.
Response:
Evidence required:
Owner and due date:

## Conditions before controlled intake

## Conditions before general launch

## Approval reference or signature
